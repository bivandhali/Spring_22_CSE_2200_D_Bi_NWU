// Create a new file, iterate.pipe.ts, in your project
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'iterate'
})
export class IteratePipe implements PipeTransform {
  transform(value: number): number[] {
    return new Array(value);
  }
}
