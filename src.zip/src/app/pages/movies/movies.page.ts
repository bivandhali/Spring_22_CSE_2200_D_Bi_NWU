import { Component, OnInit } from '@angular/core';
import { InfiniteScrollCustomEvent, LoadingController } from '@ionic/angular';
import { MovieService } from 'src/app/services/movie.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-movies',
  templateUrl: './movies.page.html',
  styleUrls: ['./movies.page.scss'],
})
export class MoviesPage implements OnInit {
  movies = [];
  currentPage = 1;
  imageBaseUrl = environment.images;
  searchQuery: string = ''; // Store the search query

  constructor(
    private movieService: MovieService,
    private loadingCtrl: LoadingController
  ) {}

  ngOnInit() {
    this.loadMovies();
  }

  async loadMovies(event?: InfiniteScrollCustomEvent) {
    const loading = await this.loadingCtrl.create({
      message: 'Loading..',
      spinner: 'bubbles',
    });
    await loading.present();

    this.movieService.getTopRatedMovies(this.currentPage).subscribe(
      (res) => {
        console.log(res);
        loading.dismiss();
        this.movies.push(...res.results);

        event?.target.complete();
        if (event) {
          event.target.disabled = res.total_pages === this.currentPage;
        }
      },
      (err) => {
        console.log(err);
        loading.dismiss();
      }
    );
  }

  get filteredMovies() {
    return this.movies
      .filter((movie) =>
        movie.title.toLowerCase().includes(this.searchQuery.toLowerCase())
      )
      .sort((a, b) => {
        // Move exact matches to the top
        if (a.title.toLowerCase() === this.searchQuery.toLowerCase()) return -1;
        if (b.title.toLowerCase() === this.searchQuery.toLowerCase()) return 1;
        return 0;
      });
  }

  onSearchInput() {
    // No need to do anything here since filteredMovies is a getter
  }


  loadMore(event: InfiniteScrollCustomEvent) {
    this.currentPage++;
    this.loadMovies(event);
  }
}