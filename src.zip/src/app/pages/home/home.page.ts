import { Component, OnInit } from '@angular/core';
import { IteratePipe } from 'src/app/pipes/iterate.pipe';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {
  searchQuery: string = ''; // Store the search query
  movies: any[] = [

    {
      title: 'Dangal',
      year: 2016,
      release_date: 'December 21, 2016',
      vote_average: 8.4,
      overview: 'Former wrestler Mahavir Singh Phogat trains his daughters Geeta and Babita to become world-class wrestlers against all odds.',
      poster_path: 'https://m.media-amazon.com/images/M/MV5BMTQ4MzQzMzM2Nl5BMl5BanBnXkFtZTgwMTQ1NzU3MDI@._V1_.jpg',
    },
    {
      title: 'Baahubali: The Beginning',
      year: 2015,
      release_date: 'July 10, 2015',
      vote_average: 8.0,
      overview: 'In ancient India, an adventurous and daring man becomes involved in a decades-old feud between two warring people.',
      poster_path: 'https://files.prokerala.com/movies/pics/800/baahubali-7th-weeks-posters-44938.jpg',
    },
    {
      title: 'Dilwale Dulhania Le Jayenge',
      year: 1995,
      release_date: 'October 20, 1995',
      vote_average: 8.2,
      overview: 'A young man and woman fall in love while traveling in Europe.',
      poster_path: 'https://m.media-amazon.com/images/I/81hpcJ-hoIL.jpg',
    },
    {
      title: 'Sholay',
      year: 1975,
      release_date: 'August 15, 1975',
      vote_average: 8.2,
      overview: 'Two criminals, Veeru and Jai, are hired by a retired police officer to capture the ruthless dacoit Gabbar Singh.',
      poster_path: 'https://m.media-amazon.com/images/I/61NhAcNBC+L.jpg',
    },
    {
      title: '3 Idiots',
      year: 2009,
      release_date: 'December 25, 2009',
      vote_average: 8.4,
      overview: 'Two friends embark on a quest for a lost buddy. On this journey, they encounter a long-forgotten bet, a wedding they must crash, and a funeral that goes impossibly out of control.',
      poster_path: 'https://m.media-amazon.com/images/M/MV5BNTkyOGVjMGEtNmQzZi00NzFlLTlhOWQtODYyMDc2ZGJmYzFhXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_.jpg',
    },
    {
      title: 'Kabhi Khushi Kabhie Gham',
      year: 2001,
      release_date: 'December 14, 2001',
      vote_average: 7.6,
      overview: 'Yashvardhan Raichand lives a very wealthy lifestyle along with his wife, Nandini, and two sons, Rahul and Rohan.',
      poster_path: 'https://m.media-amazon.com/images/M/MV5BOTQ5Nzc3NzAtMzZlMS00ZWJjLWIxMGMtNDU4ZTQ1NmNjMjc5XkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_.jpg',
    },
    {
      title: 'Lagaan',
      year: 2001,
      release_date: 'June 15, 2001',
      vote_average: 8.1,
      overview: 'The people of a small village in Victorian India stake their future on a game of cricket against their ruthless British rulers.',
      poster_path: 'https://flxt.tmsimg.com/assets/p27923_p_v11_ae.jpg',
    },
    // Add more movie objects here
  ];

  constructor() {}

  get filteredMovies() {
    return this.movies
      .filter((movie) =>
        movie.title.toLowerCase().includes(this.searchQuery.toLowerCase())
      )
      .sort((a, b) => {
        // Move exact matches to the top
        if (a.title.toLowerCase() === this.searchQuery.toLowerCase()) return -1;
        if (b.title.toLowerCase() === this.searchQuery.toLowerCase()) return 1;
        return 0;
      });
  }

  ngOnInit() {}

  onSearchInput() {
    // No need to do anything here since filteredMovies is a getter
  }

  setUserRating(movie, rating) {
    movie.userRating = rating;
  }

  // Define the submitRating method
  submitRating(movie) {
    // Handle the rating submission logic here
    console.log('Rating submitted for', movie.title);
    // You can add your logic here, such as sending the rating to a server.
  }
  

}
