export const environment = {
  production: false,
  apiKey: '42ec8e6bda8a9e48b2b4bc20b2d7057a', // <-- Enter your own key here!'
  baseUrl: 'https://api.themoviedb.org/3',
  images: 'http://image.tmdb.org/t/p',
};

/**   var hostUrl = "https://ask1place.com";
            var baseUrl = hostUrl + "/custom/mobile_app/menu/";
            var rewardsUrl = hostUrl + "/custom/mobile_app/menu/rewards/Rewards.asmx/GetActiveRewards"; */